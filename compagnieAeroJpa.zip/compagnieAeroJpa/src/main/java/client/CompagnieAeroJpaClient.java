package client;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import entity.*;

public class CompagnieAeroJpaClient {

	public static void main(String[] args) {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("CompagnieAeroJpaManager");  //Unit� de persistence = AdamingManager --> cr�er fabrique
		EntityManager em = emf.createEntityManager();		// --> cr�er gestionnaire
		EntityTransaction txn = em.getTransaction();			// -->cr�er transaction
		try {
			txn.begin();
			
			Avion avi1 = new Avion("A310", 300, "NICE");
			Avion avi2 = new Avion("B707", 250, "PARIS");
			Avion avi3 = new Avion("A300", 280, "LYON");
			Avion avi4 = new Avion("A380", 400, "NICE");
			Avion avi5 = new Avion("B747", 460, "PARIS");
			Avion avi6 = new Avion("B707", 250, "PARIS");
			Avion avi7 = new Avion("A310", 300, "TOULOUSE");
			Avion avi8 = new Avion("C200", 190, "LYON");
			Avion avi9 = new Avion("A380", 460, "PARIS");
			
			em.persist(avi1);
			em.persist(avi2);
			em.persist(avi3);
			em.persist(avi4);
			em.persist(avi5);
			em.persist(avi6);
			em.persist(avi7);
			em.persist(avi8);
			em.persist(avi9);
			
			Pilote pil1 = new Pilote("MIRANDA", "SERGE", "12 Avenu champ elysee", "75000", "PARIS", 26000.00);
			Pilote pil2 = new Pilote("LETHANH", "NAHN", "12 Rue du thor ", "31000", "TOULOUSE", 21000.00);
			Pilote pil3 = new Pilote("TALADOIRE", "GILLES", "12 Rue gambetta", "06000", "NICE", 18000.00);
			Pilote pil4 = new Pilote("CHARBONNIER", "ANNETTE", "12 Rue de la goute dor ", "75000", "PARIS", 17000.00);
			Pilote pil5 = new Pilote("REY", "CHRISTOPHE", "12 rue françois verdier", "31000", "TOULOUSE", 19000.00);
			Pilote pil6 = new Pilote("CHARBONNIER", "FABIEN", "12 Rue Champ de Mars", "75000", "PARIS", 18000.00);
			Pilote pil7 = new Pilote("PENAULD", "SERGE", "12 rue jean jaurès", "31000", "TOULOUSE", 17000.00);
			Pilote pil8 = new Pilote("FOUILHOUX", "PIERRE", "12 Rue ville de lumière", "69000", "LYON", 15000.00);
			
			em.persist(pil1);
			em.persist(pil2);
			em.persist(pil3);
			em.persist(pil4);
			em.persist(pil5);
			em.persist(pil6);
			em.persist(pil7);
			em.persist(pil8);
			
			
			Piloter piloter1 = new Piloter(pil1, avi1);
			Piloter piloter2 = new Piloter(pil2, avi2);
			Piloter piloter3 = new Piloter(pil3, avi3);
			Piloter piloter4 = new Piloter(pil4, avi4);
			Piloter piloter5 = new Piloter(pil5, avi5);
			Piloter piloter6 = new Piloter(pil6, avi6);
			Piloter piloter7 = new Piloter(pil7, avi7);
			Piloter piloter8 = new Piloter(pil8, avi8);
			
			em.persist(piloter1);
			em.persist(piloter2);
			em.persist(piloter3);
			em.persist(piloter4);
			em.persist(piloter5);
			em.persist(piloter6);
			em.persist(piloter7);
			em.persist(piloter8);
			
			Vols vol1 = new Vols(pil1, "2021-02-11", avi1);
			em.persist(vol1);
			
			Vols vol2 = new Vols(pil1, "2021-02-11", avi8);
			em.persist(vol2);
			
			Vols vol3 = new Vols(pil3, "2021-02-11", "inconnu", "LYON", "14:00:00", "16:00:00", avi1);
			em.persist(vol3);
			
			Vols vol4 = new Vols(pil5, "2021-02-11", "TOULOUSE", "LYON", "18:00:00", "20:00:00", avi3);
			em.persist(vol4);
			
			Vols vol5 = new Vols(pil8, "2021-02-11", "PARIS", "NICE", "06:45:00", "08:45:00", avi1);
			em.persist(vol5);
			
			Vols vol6 = new Vols(pil8, "2021-02-11", "LYON", "NICE", "11:00:00", "12:00:00", avi2);
			em.persist(vol6);
			
			Vols vol7 = new Vols(pil1, "2021-02-11", "PARIS", "LYON", "08:00:00", "09:00:00", avi2);
			em.persist(vol7);
			
			Vols vol8 = new Vols(pil8, "2021-02-11", "NICE", "PARIS", "07:00:00", "08:45:00", avi4);
			em.persist(vol8);
			
			Vols vol9 = new Vols(pil3, "2021-02-11", "NANTES", "LYON", "09:00:00", "15:30:00", avi8);
			em.persist(vol9);
			
			txn.commit();
			
		}catch(Exception e) {
			if(txn !=null) {txn.rollback();}
			e.printStackTrace();
		} finally {
			if(em !=null) {
				em.close();
			}
		}

	}

}
