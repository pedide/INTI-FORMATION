package entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="avion")
public class Avion {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)	
	@Column(name="aviID")
	private int aviID;
	private String aviModel;
	private int aviNbPlace;
	private String aviLocalite;
	
	@OneToMany
	List<Piloter> piloter = new ArrayList<Piloter>();
	
	@OneToMany
	List<Vols> vols = new ArrayList<Vols>();
	
	
	public Avion() {
		this("inconnu", 0, "inconnu");
	}
	
	

	public Avion(int aviID, String aviModel, int aviNbPlace, String aviLocalite, List<Vols> vols) {
		super();
		this.aviID = aviID;
		this.aviModel = aviModel;
		this.aviNbPlace = aviNbPlace;
		this.aviLocalite = aviLocalite;
		this.vols = vols;
		
		for (Vols v : this.vols) {
			v.setAvion(this);
			
		}
	}



	public Avion(String aviModel, int aviNbPlace, String aviLocalite, List<Piloter> piloter) {
		super();
		this.aviModel = aviModel;
		this.aviNbPlace = aviNbPlace;
		this.aviLocalite = aviLocalite;
		this.piloter = piloter;
		
		for (Piloter pil : this.piloter) {
			pil.setAvion(this);
		}
	}



	public Avion(String aviModel, int aviNbPlace, String aviLocalite) {
		super();
		this.aviModel = aviModel;
		this.aviNbPlace = aviNbPlace;
		this.aviLocalite = aviLocalite;
	}


	public Avion(int aviID, String aviModel, int aviNbPlace, String aviLocalite) {
		super();
		this.aviID = aviID;
		this.aviModel = aviModel;
		this.aviNbPlace = aviNbPlace;
		this.aviLocalite = aviLocalite;
	}


	public int getAviID() {
		return aviID;
	}


	public void setAviID(int aviID) {
		this.aviID = aviID;
	}


	public String getAviModel() {
		return aviModel;
	}


	public void setAviModel(String aviModel) {
		this.aviModel = aviModel;
	}


	public int getAviNbPlace() {
		return aviNbPlace;
	}


	public void setAviNbPlace(int aviNbPlace) {
		this.aviNbPlace = aviNbPlace;
	}


	public String getAviLocalite() {
		return aviLocalite;
	}


	public void setAviLocalite(String aviLocalite) {
		this.aviLocalite = aviLocalite;
	}


	public List<Piloter> getPiloter() {
		return piloter;
	}


	public void setPiloter(List<Piloter> piloter) {
		this.piloter = piloter;
	}



	public List<Vols> getVols() {
		return vols;
	}



	public void setVols(List<Vols> vols) {
		this.vols = vols;
	}
	
	
}
