package entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="pilote")
public class Pilote {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)	
	@Column(name="pilID")
	private int pilID;
	private String pilNom;
	private String pilPrenom;
	private String pilAdresse;
	private String pilCp;
	private String pilVille;
	private double pilSalaire;
	
	@OneToMany
	List<Piloter> piloter = new ArrayList<Piloter>();
	
	@OneToMany
	List<Vols> vols = new ArrayList<Vols>();
	
	
	
	public Pilote() {
		this("inconnu", "inconnu", "inconnu", "inconnu", "inconnu", 0.0);
	}
	
	
	
	public Pilote(int pilID, String pilNom, String pilPrenom, String pilAdresse, String pilCp, String pilVille,
			double pilSalaire, List<Vols> vols) {
		super();
		this.pilID = pilID;
		this.pilNom = pilNom;
		this.pilPrenom = pilPrenom;
		this.pilAdresse = pilAdresse;
		this.pilCp = pilCp;
		this.pilVille = pilVille;
		this.pilSalaire = pilSalaire;
		this.vols = vols;
		
		for (Vols v : this.vols) {
			v.setPilote(this);
			
		}
	}



	public Pilote(String pilNom, String pilPrenom, String pilAdresse, String pilCp, String pilVille, double pilSalaire,
			List<Piloter> piloter) {
		super();
		this.pilNom = pilNom;
		this.pilPrenom = pilPrenom;
		this.pilAdresse = pilAdresse;
		this.pilCp = pilCp;
		this.pilVille = pilVille;
		this.pilSalaire = pilSalaire;
		this.piloter = piloter;
		
		for (Piloter pil : this.piloter) {
			pil.setPilote(this);
		}
	}



	public Pilote(String pilNom, String pilPrenom, String pilAdresse, String pilCp, String pilVille,
			double pilSalaire) {
		super();
		this.pilNom = pilNom;
		this.pilPrenom = pilPrenom;
		this.pilAdresse = pilAdresse;
		this.pilCp = pilCp;
		this.pilVille = pilVille;
		this.pilSalaire = pilSalaire;
	}

	public Pilote(int pilID, String pilNom, String pilPrenom, String pilAdresse, String pilCp, String pilVille,
			double pilSalaire) {
		super();
		this.pilID = pilID;
		this.pilNom = pilNom;
		this.pilPrenom = pilPrenom;
		this.pilAdresse = pilAdresse;
		this.pilCp = pilCp;
		this.pilVille = pilVille;
		this.pilSalaire = pilSalaire;
	}

	public int getPilID() {
		return pilID;
	}

	public void setPilID(int pilID) {
		this.pilID = pilID;
	}

	public String getPilNom() {
		return pilNom;
	}

	public void setPilNom(String pilNom) {
		this.pilNom = pilNom;
	}

	public String getPilPrenom() {
		return pilPrenom;
	}

	public void setPilPrenom(String pilPrenom) {
		this.pilPrenom = pilPrenom;
	}

	public String getPilAdresse() {
		return pilAdresse;
	}

	public void setPilAdresse(String pilAdresse) {
		this.pilAdresse = pilAdresse;
	}

	public String getPilCp() {
		return pilCp;
	}

	public void setPilCp(String pilCp) {
		this.pilCp = pilCp;
	}

	public String getPilVille() {
		return pilVille;
	}

	public void setPilVille(String pilVille) {
		this.pilVille = pilVille;
	}

	public double getPilSalaire() {
		return pilSalaire;
	}

	public void setPilSalaire(double pilSalaire) {
		this.pilSalaire = pilSalaire;
	}

	public List<Piloter> getPiloter() {
		return piloter;
	}

	public void setPiloter(List<Piloter> piloter) {
		this.piloter = piloter;
	}



	public List<Vols> getVols() {
		return vols;
	}



	public void setVols(List<Vols> vols) {
		this.vols = vols;
	}

	
	
}
