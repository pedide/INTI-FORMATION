package entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


@Entity
@Table(name="piloter")
public class Piloter {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "idPiloter")
	private int idPiloter;
	
	@ManyToOne
	@JoinColumn(name= "pilot_pilID")
	private Pilote pilote;
	
	@ManyToOne
	@JoinColumn(name= "avion_aviID")
	private Avion avion;

	
	

	public Piloter(Pilote pilote, Avion avion) {
		super();
		this.pilote = pilote;
		this.avion = avion;
	}

	public Piloter(int idPiloter, Pilote pilote, Avion avion) {
		super();
		this.idPiloter = idPiloter;
		this.pilote = pilote;
		this.avion = avion;
	}

	public int getIdPiloter() {
		return idPiloter;
	}

	public void setIdPiloter(int idPiloter) {
		this.idPiloter = idPiloter;
	}

	public Pilote getPilote() {
		return pilote;
	}

	public void setPilote(Pilote pilote) {
		this.pilote = pilote;
	}

	public Avion getAvion() {
		return avion;
	}

	public void setAvion(Avion avion) {
		this.avion = avion;
	}
	
	
}
