package entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="vols")
public class Vols {
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "volID")
	private int volID;
	
	@ManyToOne
	@JoinColumn(name= "volPilID")
	private Pilote pilote;
	
	private String volDate;
	private String volDepart;
	private String volArrivee;
	private String volHeureDepart;
	private String volHeureArrivee;
	
	@ManyToOne
	@JoinColumn(name= "volAviID")
	private Avion avion;	
	
	
	public Vols() {
		this("inconnu", "inconnu", "inconnu", "inconnu", "inconnu");
	}
	
	
	
	public Vols(Pilote pilote, String volDate, Avion avion) {
		super();
		this.pilote = pilote;
		this.volDate = volDate;
		this.avion = avion;
	}



	public Vols(Pilote pilote, String volDate, String volDepart, String volArrivee, String volHeureDepart,
			String volHeureArrivee, Avion avion) {
		super();
		this.pilote = pilote;
		this.volDate = volDate;
		this.volDepart = volDepart;
		this.volArrivee = volArrivee;
		this.volHeureDepart = volHeureDepart;
		this.volHeureArrivee = volHeureArrivee;
		this.avion = avion;
	}



	public Vols(int volID, Pilote pilote, String volDate, String volDepart, String volArrivee, String volHeureDepart,
			String volHeureArrivee, Avion avion) {
		super();
		this.volID = volID;
		this.pilote = pilote;
		this.volDate = volDate;
		this.volDepart = volDepart;
		this.volArrivee = volArrivee;
		this.volHeureDepart = volHeureDepart;
		this.volHeureArrivee = volHeureArrivee;
		this.avion = avion;
	}



	public Vols(String volDate, String volDepart, String volArrivee, String volHeureDepart, String volHeureArrivee) {
		super();
		this.volDate = volDate;
		this.volDepart = volDepart;
		this.volArrivee = volArrivee;
		this.volHeureDepart = volHeureDepart;
		this.volHeureArrivee = volHeureArrivee;
	}
	public int getVolID() {
		return volID;
	}
	public void setVolID(int volID) {
		this.volID = volID;
	}

	
	public String getVolDate() {
		return volDate;
	}
	public void setVolDate(String volDate) {
		this.volDate = volDate;
	}
	public String getVolDepart() {
		return volDepart;
	}
	public void setVolDepart(String volDepart) {
		this.volDepart = volDepart;
	}
	public String getVolArrivee() {
		return volArrivee;
	}
	public void setVolArrivee(String volArrivee) {
		this.volArrivee = volArrivee;
	}
	public String getVolHeureDepart() {
		return volHeureDepart;
	}
	public void setVolHeureDepart(String volHeureDepart) {
		this.volHeureDepart = volHeureDepart;
	}
	public String getVolHeureArrivee() {
		return volHeureArrivee;
	}
	public void setVolHeureArrivee(String volHeureArrivee) {
		this.volHeureArrivee = volHeureArrivee;
	}
	public Pilote getPilote() {
		return pilote;
	}
	public void setPilote(Pilote pilote) {
		this.pilote = pilote;
	}
	public Avion getAvion() {
		return avion;
	}
	public void setAvion(Avion avion) {
		this.avion = avion;
	}

	
	
}
