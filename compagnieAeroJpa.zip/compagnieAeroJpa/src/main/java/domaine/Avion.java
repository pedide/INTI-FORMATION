package domaine;

public class Avion {
	
	private int aviID;
	private String aviModel;
	private int aviNbPlace;
	private String aviLocalite;
	
	
	
	public Avion() {
		this("inconnu", 0, "inconnu");
	}


	public Avion(String aviModel, int aviNbPlace, String aviLocalite) {
		super();
		this.aviModel = aviModel;
		this.aviNbPlace = aviNbPlace;
		this.aviLocalite = aviLocalite;
	}


	public Avion(int aviID, String aviModel, int aviNbPlace, String aviLocalite) {
		super();
		this.aviID = aviID;
		this.aviModel = aviModel;
		this.aviNbPlace = aviNbPlace;
		this.aviLocalite = aviLocalite;
	}


	public int getAviID() {
		return aviID;
	}


	public void setAviID(int aviID) {
		this.aviID = aviID;
	}


	public String getAviModel() {
		return aviModel;
	}


	public void setAviModel(String aviModel) {
		this.aviModel = aviModel;
	}


	public int getAviNbPlace() {
		return aviNbPlace;
	}


	public void setAviNbPlace(int aviNbPlace) {
		this.aviNbPlace = aviNbPlace;
	}


	public String getAviLocalite() {
		return aviLocalite;
	}


	public void setAviLocalite(String aviLocalite) {
		this.aviLocalite = aviLocalite;
	}
	
	
}
