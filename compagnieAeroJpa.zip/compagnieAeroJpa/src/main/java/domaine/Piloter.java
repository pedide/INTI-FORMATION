package domaine;

public class Piloter {
	
	private int pilot_pilID;
	private int avion_aviID;
	
}
