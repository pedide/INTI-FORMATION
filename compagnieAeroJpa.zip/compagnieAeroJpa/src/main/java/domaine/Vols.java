package domaine;

public class Vols {
	
	private int volID;
	private int volPilID;
	private String volDate;
	private String volDepart;
	private String volArrivee;
	private String volHeureDepart;
	private String volHeureArrivee;
	private int volAviID;	
	
	
	public Vols() {
		this("inconnu", "inconnu", "inconnu", "inconnu", "inconnu");
	}
	public Vols(String volDate, String volDepart, String volArrivee, String volHeureDepart, String volHeureArrivee) {
		super();
		this.volDate = volDate;
		this.volDepart = volDepart;
		this.volArrivee = volArrivee;
		this.volHeureDepart = volHeureDepart;
		this.volHeureArrivee = volHeureArrivee;
	}
	public int getVolID() {
		return volID;
	}
	public void setVolID(int volID) {
		this.volID = volID;
	}
	public int getVolPilID() {
		return volPilID;
	}
	public void setVolPilID(int volPilID) {
		this.volPilID = volPilID;
	}
	public String getVolDate() {
		return volDate;
	}
	public void setVolDate(String volDate) {
		this.volDate = volDate;
	}
	public String getVolDepart() {
		return volDepart;
	}
	public void setVolDepart(String volDepart) {
		this.volDepart = volDepart;
	}
	public String getVolArrivee() {
		return volArrivee;
	}
	public void setVolArrivee(String volArrivee) {
		this.volArrivee = volArrivee;
	}
	public String getVolHeureDepart() {
		return volHeureDepart;
	}
	public void setVolHeureDepart(String volHeureDepart) {
		this.volHeureDepart = volHeureDepart;
	}
	public String getVolHeureArrivee() {
		return volHeureArrivee;
	}
	public void setVolHeureArrivee(String volHeureArrivee) {
		this.volHeureArrivee = volHeureArrivee;
	}
	public int getVolAviID() {
		return volAviID;
	}
	public void setVolAviID(int volAviID) {
		this.volAviID = volAviID;
	}
	
	
}
