/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author sovannroth
 */
@Entity
@Table(name= "clients")
public class Client {
    
	@Id
	@Column(name= "idCli")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
    private int idCli;
    private String nomCli;
    private String prenomCli;
    private String adresseCli;
    private String cpCli;
    private String villeCli;
    
    @ManyToOne
    @JoinColumn(name= "cliIDProd")
    private Produit produit;
    
    @OneToMany
    private List<Adoption> adoptions = new ArrayList<Adoption>();
    
    @OneToMany
    private List<Achat> achat = new ArrayList<Achat>();
    
    

    public Client() {
		this("inconnu", "inconnu", "inconnu", "inconnu", "inconnu");
		for (Adoption ad : adoptions) {
			ad.setClient(this);
		}
		for (Achat ac : achat) {
			ac.setClient(this);
		}
	}
    
    

	public Client(String nomCli, String prenomCli, String adresseCli, String cpCli, String villeCli) {
		super();
		this.nomCli = nomCli;
		this.prenomCli = prenomCli;
		this.adresseCli = adresseCli;
		this.cpCli = cpCli;
		this.villeCli = villeCli;
	}



	public Client(String nomCli, String prenomCli, String adresseCli, String cpCli, String villeCli, Produit produit) {
		super();
		this.nomCli = nomCli;
		this.prenomCli = prenomCli;
		this.adresseCli = adresseCli;
		this.cpCli = cpCli;
		this.villeCli = villeCli;
		this.produit = produit;
	}

	public Client(int idCli, String nomCli, String prenomCli, String adresseCli, String cpCli, String villeCli) {
        this.idCli = idCli;
        this.nomCli = nomCli;
        this.prenomCli = prenomCli;
        this.adresseCli = adresseCli;
        this.cpCli = cpCli;
        this.villeCli = villeCli;
    }
	
	
    public List<Adoption> getAdoptions() {
		return adoptions;
	}



	public void setAdoptions(List<Adoption> adoptions) {
		this.adoptions = adoptions;
	}



	public List<Achat> getAchat() {
		return achat;
	}



	public void setAchat(List<Achat> achat) {
		this.achat = achat;
	}



	public int getIdCli() {
        return idCli;
    }

    public void setIdCli(int idCli) {
        this.idCli = idCli;
    }

    public String getNomCli() {
        return nomCli;
    }

    public void setNomCli(String nomCli) {
        this.nomCli = nomCli;
    }

    public String getPrenomCli() {
        return prenomCli;
    }

    public void setPrenomCli(String prenomCli) {
        this.prenomCli = prenomCli;
    }

    public String getAdresseCli() {
        return adresseCli;
    }

    public void setAdresseCli(String adresseCli) {
        this.adresseCli = adresseCli;
    }

    public String getCpCli() {
        return cpCli;
    }

    public void setCpCli(String cpCli) {
        this.cpCli = cpCli;
    }

    public String getVilleCli() {
        return villeCli;
    }

    public void setVilleCli(String villeCli) {
        this.villeCli = villeCli;
    }

    @Override
    public String toString() {
        return "Client{" + "idCli=" + idCli + ", nomCli=" + nomCli + ", prenomCli=" + prenomCli + ", adresseCli=" + adresseCli + ", cpCli=" + cpCli + ", villeCli=" + villeCli + '}';
    }

	public Produit getProduit() {
		return produit;
	}

	public void setProduit(Produit produit) {
		this.produit = produit;
	}
    
    
}
