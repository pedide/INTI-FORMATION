/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author sovannroth
 */

@Entity
@Table(name= "animal")
public class Animal {
	
	@Id
	@Column(name= "idAnim")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
    private int idAnim;
    private String espece;
    private String sex;
    private String dateNaissance;
    private String nom;
    private String commentaire;
    
    @OneToMany
    private List<Adoption> adoptions = new ArrayList<Adoption>();

    
    public Animal() {
		this("inconnu", "inconnu", "inconnu", "inconnu", "inconnu");
		for (Adoption ad : adoptions) {
			ad.setAnimal(this);
		}
	}



	public Animal(String espece, String sex, String dateNaissance, String nom, String commentaire) {
		super();
		this.espece = espece;
		this.sex = sex;
		this.dateNaissance = dateNaissance;
		this.nom = nom;
		this.commentaire = commentaire;
	}



	public Animal(String espece, String sex, String dateNaissance, String nom, String commentaire,
			List<Adoption> adoptions) {
		super();
		this.espece = espece;
		this.sex = sex;
		this.dateNaissance = dateNaissance;
		this.nom = nom;
		this.commentaire = commentaire;
		this.adoptions = adoptions;
	}



	public Animal(int idAnim, String espece, String sex, String dateNaissance, String nom, String commentaire) {
        this.idAnim = idAnim;
        this.espece = espece;
        this.sex = sex;
        this.dateNaissance = dateNaissance;
        this.nom = nom;
        this.commentaire = commentaire;
    }

    
    
    public List<Adoption> getAdoptions() {
		return adoptions;
	}



	public void setAdoptions(List<Adoption> adoptions) {
		this.adoptions = adoptions;
	}



	public int getIdAnim() {
        return idAnim;
    }

    public void setIdAnim(int idAnim) {
        this.idAnim = idAnim;
    }

    public String getEspece() {
        return espece;
    }

    public void setEspece(String espece) {
        this.espece = espece;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getDateNaissance() {
        return dateNaissance;
    }

    public void setDateNaissance(String dateNaissance) {
        
        this.dateNaissance = dateNaissance;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getCommentaire() {
        return commentaire;
    }

    public void setCommentaire(String commentaire) {
        this.commentaire = commentaire;
    }

    @Override
    public String toString() {
        return "Animal{" + "idAnim=" + idAnim + ", espece=" + espece + ", sex=" + sex + ", dateNaissance=" + dateNaissance + ", nom=" + nom + ", commentaire=" + commentaire + '}';
    }
    
    
}
