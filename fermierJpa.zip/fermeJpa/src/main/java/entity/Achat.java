package entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name= "achat")
public class Achat {
	
	@Id
	@Column(name= "idAchat")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int idAchat;

    @ManyToOne
    @JoinColumn(name= "achatIDVoit")
    private Voiture voiture;
    
    @ManyToOne
    @JoinColumn(name= "achatIDCli")
    private Client client;
	
	public Achat() {
		super();
	}


	public Achat(Voiture voiture, Client client) {
		super();
		this.voiture = voiture;
		this.client = client;
	}



	public Achat(int idAchat, Voiture voiture, Client client) {
		super();
		this.idAchat = idAchat;
		this.voiture = voiture;
		this.client = client;
	}



	public Achat(int idAchat) {
		super();
		this.idAchat = idAchat;
	}

	public int getIdAchat() {
		return idAchat;
	}

	public void setIdAchat(int idAchat) {
		this.idAchat = idAchat;
	}

	public Voiture getVoiture() {
		return voiture;
	}

	public void setVoiture(Voiture voiture) {
		this.voiture = voiture;
	}

	public Client getClient() {
		return client;
	}

	public void setClient(Client client) {
		this.client = client;
	}
	
}
