/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author sovannroth
 */

@Entity
@Table(name= "produit")
public class Produit {
    
	@Id
	@Column(name= "idProd")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
    private int idProd;
    private String prodNom;
    private double prodPrix;
    private String designation;
    
    @OneToMany
    private List<Client> clients = new ArrayList<Client>();
    
    public Produit() {
		this("inconnu", 0.0, "inconnu");
		for (Client client : clients) {
			client.setProduit(this);
		}
	}


	public Produit(String prodNom, double prodPrix, String designation, List<Client> clients) {
		super();
		this.prodNom = prodNom;
		this.prodPrix = prodPrix;
		this.designation = designation;
		this.clients = clients;
	}


	public Produit(String prodNom, double prodPrix, String designation) {
		super();
		this.prodNom = prodNom;
		this.prodPrix = prodPrix;
		this.designation = designation;
	}


	public Produit(int idProd, String prodNom, double prodPrix, String designation) {
		super();
		this.idProd = idProd;
		this.prodNom = prodNom;
		this.prodPrix = prodPrix;
		this.designation = designation;
	}


	public int getIdProd() {
		return idProd;
	}


	public void setIdProd(int idProd) {
		this.idProd = idProd;
	}


	public String getProdNom() {
		return prodNom;
	}


	public void setProdNom(String prodNom) {
		this.prodNom = prodNom;
	}


	public double getProdPrix() {
		return prodPrix;
	}


	public void setProdPrix(double prodPrix) {
		this.prodPrix = prodPrix;
	}


	public String getDesignation() {
		return designation;
	}


	public void setDesignation(String designation) {
		this.designation = designation;
	}


    
}
