/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domaine;

/**
 *
 * @author sovannroth
 */
public class Adoption {
    private int idAdoption;
    private String dateAdoption;
    private double prixAdoption;
    private int certifAdoption;
    private int adoptIdCli;
    private int adoptIdAnim;

    public Adoption(int idAdoption, String dateAdoption, double prixAdoption, int certifAdoption, int adoptIdCli, int adoptIdAnim) {
        this.idAdoption = idAdoption;
        this.dateAdoption = dateAdoption;
        this.prixAdoption = prixAdoption;
        this.certifAdoption = certifAdoption;
        this.adoptIdCli = adoptIdCli;
        this.adoptIdAnim = adoptIdAnim;
    }

    public int getIdAdoption() {
        return idAdoption;
    }

    public void setIdAdoption(int idAdoption) {
        this.idAdoption = idAdoption;
    }

    public String getDateAdoption() {
        return dateAdoption;
    }

    public void setDateAdoption(String dateAdoption) {
        this.dateAdoption = dateAdoption;
    }

    public double getPrixAdoption() {
        return prixAdoption;
    }

    public void setPrixAdoption(double prixAdoption) {
        this.prixAdoption = prixAdoption;
    }

    public int getCertifAdoption() {
        return certifAdoption;
    }

    public void setCertifAdoption(int certifAdoption) {
        this.certifAdoption = certifAdoption;
    }

    public int getAdoptIdCli() {
        return adoptIdCli;
    }

    public void setAdoptIdCli(int adoptIdCli) {
        this.adoptIdCli = adoptIdCli;
    }

    public int getAdoptIdAnim() {
        return adoptIdAnim;
    }

    public void setAdoptIdAnim(int adoptIdAnim) {
        this.adoptIdAnim = adoptIdAnim;
    }

    @Override
    public String toString() {
        return "Adoption{" + "idAdoption=" + idAdoption + ", dateAdoption=" + dateAdoption + ", prixAdoption=" + prixAdoption + ", certifAdoption=" + certifAdoption + ", adoptIdCli=" + adoptIdCli + ", adoptIdAnim=" + adoptIdAnim + '}';
    }
    
    
}
