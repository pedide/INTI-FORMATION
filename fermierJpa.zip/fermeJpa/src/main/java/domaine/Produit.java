/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domaine;

/**
 *
 * @author sovannroth
 */
public class Produit {
    
    private int idProd;
    private String nomProd;
    private double prixProd;
    private String designation;

    public Produit(int idProd, String nomProd, double prixProd, String designation) {
        this.idProd = idProd;
        this.nomProd = nomProd;
        this.prixProd = prixProd;
        this.designation = designation;
    }

    public int getIdProd() {
        return idProd;
    }

    public void setIdProd(int idProd) {
        this.idProd = idProd;
    }

    public String getNomProd() {
        return nomProd;
    }

    public void setNomProd(String nomProd) {
        this.nomProd = nomProd;
    }

    public double getPrixProd() {
        return prixProd;
    }

    public void setPrixProd(double prixProd) {
        this.prixProd = prixProd;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    @Override
    public String toString() {
        return "Produit{" + "idProd=" + idProd + ", nomProd=" + nomProd + ", prixProd=" + prixProd + ", designation=" + designation + '}';
    }
    
    
}
