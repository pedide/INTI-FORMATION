/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domaine;

/**
 *
 * @author sovannroth
 */
public class Voiture {
    private int idVoit;
    private String modelVoit;
    private String couleurVoit;
    private String immatVoit;
    private int puissanceVoit;

    public Voiture(int idVoit, String modelVoit, String couleurVoit, String immatVoit, int puissanceVoit) {
        this.idVoit = idVoit;
        this.modelVoit = modelVoit;
        this.couleurVoit = couleurVoit;
        this.immatVoit = immatVoit;
        this.puissanceVoit = puissanceVoit;
    }

    public int getIdVoit() {
        return idVoit;
    }

    public void setIdVoit(int idVoit) {
        this.idVoit = idVoit;
    }

    public String getModelVoit() {
        return modelVoit;
    }

    public void setModelVoit(String modelVoit) {
        this.modelVoit = modelVoit;
    }

    public String getCouleurVoit() {
        return couleurVoit;
    }

    public void setCouleurVoit(String couleurVoit) {
        this.couleurVoit = couleurVoit;
    }

    public String getImmatVoit() {
        return immatVoit;
    }

    public void setImmatVoit(String immatVoit) {
        this.immatVoit = immatVoit;
    }

    public int getPuissanceVoit() {
        return puissanceVoit;
    }

    public void setPuissanceVoit(int puissanceVoit) {
        this.puissanceVoit = puissanceVoit;
    }

    @Override
    public String toString() {
        return "Voiture{" + "idVoit=" + idVoit + ", modelVoit=" + modelVoit + ", couleurVoit=" + couleurVoit + ", immatVoit=" + immatVoit + ", puissanceVoit=" + puissanceVoit + '}';
    }
    
    
}
