package domaine;

public class Achat {
	
	private int idAchat;

	
	
	public Achat() {
		super();
	}

	public Achat(int idAchat) {
		super();
		this.idAchat = idAchat;
	}

	public int getIdAchat() {
		return idAchat;
	}

	public void setIdAchat(int idAchat) {
		this.idAchat = idAchat;
	}
	
}
