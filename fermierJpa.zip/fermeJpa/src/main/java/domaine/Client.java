/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domaine;

/**
 *
 * @author sovannroth
 */
public class Client {
    
    private int idCli;
    private String nomCli;
    private String prenomCli;
    private String adresseCli;
    private String cpCli;
    private String villeCli;

    public Client(int idCli, String nomCli, String prenomCli, String adresseCli, String cpCli, String villeCli) {
        this.idCli = idCli;
        this.nomCli = nomCli;
        this.prenomCli = prenomCli;
        this.adresseCli = adresseCli;
        this.cpCli = cpCli;
        this.villeCli = villeCli;
    }

    public int getIdCli() {
        return idCli;
    }

    public void setIdCli(int idCli) {
        this.idCli = idCli;
    }

    public String getNomCli() {
        return nomCli;
    }

    public void setNomCli(String nomCli) {
        this.nomCli = nomCli;
    }

    public String getPrenomCli() {
        return prenomCli;
    }

    public void setPrenomCli(String prenomCli) {
        this.prenomCli = prenomCli;
    }

    public String getAdresseCli() {
        return adresseCli;
    }

    public void setAdresseCli(String adresseCli) {
        this.adresseCli = adresseCli;
    }

    public String getCpCli() {
        return cpCli;
    }

    public void setCpCli(String cpCli) {
        this.cpCli = cpCli;
    }

    public String getVilleCli() {
        return villeCli;
    }

    public void setVilleCli(String villeCli) {
        this.villeCli = villeCli;
    }

    @Override
    public String toString() {
        return "Client{" + "idCli=" + idCli + ", nomCli=" + nomCli + ", prenomCli=" + prenomCli + ", adresseCli=" + adresseCli + ", cpCli=" + cpCli + ", villeCli=" + villeCli + '}';
    }
    
    
}
