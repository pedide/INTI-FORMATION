/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domaine;

import java.util.Date;

/**
 *
 * @author sovannroth
 */
public class Animal {
    private int idAnim;
    private String espece;
    private String sex;
    private String dateNaissance;
    private String nom;
    private String commentaire;

    public Animal(int idAnim, String espece, String sex, String dateNaissance, String nom, String commentaire) {
        this.idAnim = idAnim;
        this.espece = espece;
        this.sex = sex;
        this.dateNaissance = dateNaissance;
        this.nom = nom;
        this.commentaire = commentaire;
    }

    public int getIdAnim() {
        return idAnim;
    }

    public void setIdAnim(int idAnim) {
        this.idAnim = idAnim;
    }

    public String getEspece() {
        return espece;
    }

    public void setEspece(String espece) {
        this.espece = espece;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getDateNaissance() {
        return dateNaissance;
    }

    public void setDateNaissance(String dateNaissance) {
        
        this.dateNaissance = dateNaissance;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getCommentaire() {
        return commentaire;
    }

    public void setCommentaire(String commentaire) {
        this.commentaire = commentaire;
    }

    @Override
    public String toString() {
        return "Animal{" + "idAnim=" + idAnim + ", espece=" + espece + ", sex=" + sex + ", dateNaissance=" + dateNaissance + ", nom=" + nom + ", commentaire=" + commentaire + '}';
    }
    
    
}
