/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Client;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import entity.*;

/**
 *
 * @author sovannroth
 */
public class FermeJpaClient {


    public static void main(String[] args)  {
    	// Cr�ation de mon gestionnaire d'entit�
		
    			EntityManagerFactory emf = Persistence.createEntityManagerFactory("FermierManager");  //Unit� de persistence = AdamingManager --> cr�er fabrique
    			EntityManager em = emf.createEntityManager();		// --> cr�er gestionnaire
    			EntityTransaction txn = em.getTransaction();			// -->cr�er transaction
    			try {
    				txn.begin();

    				Produit prod1 = new Produit("raspberryPi", 30.0, "neuve");
    				em.persist(prod1);
    				
    				Client cli1 = new Client("escoba", "pablo", "100 rue de l'enfer", "10000", "MEDELINE");
    				cli1.setProduit(prod1);
    				em.persist(cli1);
    				
    				Animal anim1 = new Animal("aligator", "f", "2021-07-14", "mangetout", "mange tous ce qui bouge");
    				em.persist(anim1);
    				
    				Adoption ad1 = new Adoption("2021-07-14", 250.00, 1, cli1, anim1);
    				em.persist(ad1);
    				
    				Voiture v1 = new Voiture("Wrangler", "vert fluo", "AQ-543-FR", 135);
    				em.persist(v1);
    				
    				Achat ac1 = new Achat(v1, cli1);
    				em.persist(ac1);
    				
    				txn.commit();
    				
    			}catch(Exception e) {
    				if(txn !=null) {txn.rollback();}
    				e.printStackTrace();
    			} finally {
    				if(em !=null) {
    					em.close();
    				}
    			}

    }
    
}
